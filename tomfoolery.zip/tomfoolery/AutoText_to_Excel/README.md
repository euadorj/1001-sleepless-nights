//
to convert any text list to an excel spreadsheet, user simply has to type in headers and categories and program should generate an exported csv file for user. 


should not matter:
1. how it is structured
2. categories should not be pointed out. (should ownself organise and search/sort)

USER SHOULD ONLY DO 2 THINGS
1. EITHER upload text file OR copy paste text list 
2. type categories(headers) in 
3. type what the name of the outputted file should be. 


*note:
done this in both C++ and py since these are the languages that im most familiar with. A java solution is in the works. 


given sample data set: 

SPNYP blessing packs 
Mei Si 
Xuezy
Emilia 
Adeline 
Jadyn 

SPA
Shri — teh ping
Ian — caffeine kosong 
David — white monster 
Emilia — milo 
Starfish (xin yu) — teh C gao 
Mei si — coffee 

SPB
Chayce (Silas) — teh ping 
Austen — kopi O kosong 
kentzo — Pokka green tea 
Caleb — Pokka green tea 
Brandon — cold water / Pocari sweat
Song jek — coke / sprite
Heng jeang — fruit tea
Jaslyn — chagee — osmanthus 
Sean — Coke Zero 
Zeos — Coke Zero 
Dione — ice lemon tea 


NYPA (mervyn — ABC soup) 
Meiyi — bbt
Keene — AnW
Shane — fresh milk teas 
Jadyn — matcha 
Xuan an — dong ding cream with pearl 50% sugar less ice from chicha 
Joie — bbt 
Joshua — green tea teh C ping siu tai 
Mikayla —  berry tea/ strawberry  matcha 
Jovial — warm water 

NYPB
Toby — AnW
Silas — apple juice 
xuezy — Coke Zero 
Xuanming — dou hua shui
Hanna — iced peach tea from chicha
Junxian — strawberry milk 

NYPC
Esther — kopi O kosong (copycat siah) 
Randall — bbt 
Eva — iced matcha latte
Adeline — water 
Joel — pineapple juice 
Egan — ayataka / cold water 