#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <regex>
#include <sstream>
#include <map>
#include <iomanip>

/* Known Bugs
since im using a online complier, uploadFile might not work. currently it gives user no time to send file path and immedaitely gives error message
my idea is getting users to upload like in html/js kind 

*/ 


namespace AutoTextExcel { // init values for debug ONLY will remove later
    std::vector<std::string> Headers = {"name", "money"};
    std::vector<std::string> Data = {"joker 155", "heidi >> 132", "john (1800)", "abc -- 184"};

    void uploadFile() {
        std::string filePath;
        std::cout << "Enter the path of the file you want to upload: ";
        std::getline(std::cin, filePath);  // Get the file path from the user

        std::ifstream inputFile(filePath);  // Open the file
        if (!inputFile) {  // Check if the file opened successfully
            std::cerr << "Error opening file: " << filePath << std::endl;
            return;  // Exit the function if the file could not be opened
        }

        std::string line;
        while (std::getline(inputFile, line)) {
            Data.push_back(line);  // Store each line in the data vector
        }

        inputFile.close();  // Close the file
        std::cout << "File uploaded successfully!" << std::endl;
        std::cout << "You entered this:\n";  // Fixed typo in output message
        for (const std::string& i : Data) {
            std::cout << i << std::endl;  // Print each line
        }
    }  // Added missing closing brace for uploadFile

    // Function for user to enter data manually
    void uploadData() {
        std::string data_input;
        std::cout << "Enter values (type 'end' to finish): ";

        while (true) {
            std::getline(std::cin, data_input);
            if (data_input == "end") {
                break;
            }
            Data.push_back(data_input);  // Store user input into the Data vector
        }

        std::cout << "You entered:\n";
        for (const std::string& i : Data) {
            std::cout << i << std::endl;  // Display the entered data
        }
    }

    void SetHeaders() {
        std::string header_input;
        std::cout << "Enter values (type 'end' to finish): ";

        while (true) {
            std::getline(std::cin, header_input);
            if (header_input == "end") {
                break;
            }
            Headers.push_back(header_input);
        }

        std::cout << "You entered:\n";
        for (const std::string& value : Headers) {
            std::cout << value << std::endl;  // Display the entered headers
        }
    }
    void ProcessData() {
        // Define the regex pattern to match >>, (), and --
        std::regex pattern(R"([\(\)\>\-]{1,2})");
        
        // Iterate over each string in the data vector
        for (auto& entry : Data) {
            // Replace matches with two spaces
            entry = std::regex_replace(entry, pattern, "  ");
        }
    }
    void viewData() {
        if (Headers.empty()) {
            std::cout << "No headers set." << std::endl;
            return;
        }

        if (Data.empty()) {
            std::cout << "No data available." << std::endl;
            return;
        }

        ProcessData();

        // Display headers
        std::cout << std::setw(15) << Headers[0];  // Adjust width as necessary
        for (std::size_t i = 1; i < Headers.size(); ++i) {
            std::cout << std::setw(15) << Headers[i];
        }
        std::cout << std::endl;

        // Display data
        for (const auto& entry : Data) {
            std::istringstream ss(entry);
            std::string word;
            std::size_t colIndex = 0;

            while (ss >> word) {
                std::cout << std::setw(15) << word;
                colIndex++;
                if (colIndex >= Headers.size()) {
                    break;  // Stop if we exceed the number of headers
                }
            }
            std::cout << std::endl;
        }
    }
    void exportData() {
        std::string fileName;
        std::cout << "Enter the name of the CSV file to export (without .csv): ";
        std::getline(std::cin, fileName);
        fileName += ".csv";  // Append .csv extension

        ProcessData();

        std::ofstream outputFile(fileName);
        if (!outputFile) {
            std::cerr << "Error creating file: " << fileName << std::endl;
            return;
        }

        // Write headers to the file
        for (size_t i = 0; i < Headers.size(); ++i) {
            outputFile << Headers[i];
            if (i < Headers.size() - 1) {
                outputFile << ",";  // Add a comma after each header except the last
            }
        }
        outputFile << "\n";  // New line after headers

        // Write data to the file
        for (const auto& entry : Data) {
            outputFile << entry << "\n";  // Each entry in a new line
        }

        outputFile.close();
        std::cout << "Data exported successfully to " << fileName << std::endl;
    }


    void MainMenu() {
        std::map<std::string, std::function<void()>> menuOptions = {
            {"1", uploadFile},
            {"2", SetHeaders},
            {"3", uploadData},
            {"4", viewData},
            {"5", exportData}
        };

        std::string choice;

        while (true) {
            std::cout << "Menu:\n";
            std::cout << "1. Import file\n";
            std::cout << "2. Set header\n";
            std::cout << "3. Upload Data\n";
            std::cout << "4. View Data\n";
            std::cout << "5. Export Data (.csv)\n";

            std::cout << "Type 'exit' to quit.\n";
            std::cout << "Enter your choice (1-5 or 'exit'): ";

            std::getline(std::cin, choice); // Get user input

            if (choice == "exit") {
                break; // Exit the loop
            }

            // Use map lookup to call the appropriate function
            auto it = menuOptions.find(choice);
            if (it != menuOptions.end()) {
                it->second(); // Call the function
            } else {
                std::cout << "Invalid choice, please enter a number between 1 and 3 or 'exit'." << std::endl;
            }
        }
    }
}

int main() {
    AutoTextExcel::MainMenu();
    return 0;
}



// I have a few questions, help me debug 
// 1. what if the user sends a file that is not meant to be used for making into a excel? ie notes how would the program read and give error message ? program needs to be able to read and give feedback to user if the file they sent is viable for making into a excel
// 2. what if the user sends the whole list using uploadData? the program needs to be able to recognise what the headers are in the list and generate the headers, because assume that the user is lazy and does not want to/ does not know of the categories at the start. 
// 3. when I export, the spacing between elements and graphical view is not the same as viewData. 

// give me sample data and example of how it would work 

// data should be separated by spaces 
// ie 
// joker 155
// Heidi 180

// should display message warning the user that this text is not viable a sample would be like 
// “Seek me and live!”
// “Don’t go into the cities for they will be destroyed and go into exile”

// Samuel — preached in the circuit 
// Isaiah 55:6-7 
// Seek the Lord while He may be found. 
// Let Him turn to the Lord, and He will have mercy on Him, and to Our God, for He will surely pardon.”

// Seek His ways and walk in them 

// this should not be able to be parsed into a excel file because the textual content does not make it possible for it to be parsed